# Programmig Language, 2023 Spring, Assignment 2
## Due: April 9 Sun, 11:59 pm

---
## How to build hw1.cpp
### Linux and MacOS
./cc.sh
./a.out

### Windows
g++ --std=c++17 hw2.cc
a.exe

---
## If you build with the skeleton initialized, you'll get an error. This is normal.