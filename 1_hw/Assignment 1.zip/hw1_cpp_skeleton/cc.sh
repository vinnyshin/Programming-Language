#!/bin/bash
set -x
g++ --std=c++17 hw1.cpp
