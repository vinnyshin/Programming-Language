# Programmig Language, 2023 Spring, Assignment 1
## Due: March 19 Sun, 11:59 pm

---
## Getting Started
### How to build hw1.cpp
#### Linux
./cc.sh

#### MacOS
./cc.sh

#### Windows
g++ --std=c++17 hw1.cpp

### __MACOSX
This is the folder that was created when compressing on macOS. If you're not on macOS, you can delete it.

### If you build with the skeleton initialized, you'll get an error. This is normal.